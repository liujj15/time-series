import os
os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import numpy as np
import argparse
import torch
from torch import nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torch import optim
from tqdm import tqdm
from torch.utils.data import DataLoader
from data import ITSCDataset
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import math
from scipy.stats import gaussian_kde
from inception import Inception, InceptionBlock





class Flatten(nn.Module):
    def __init__(self, out_features):
        super(Flatten, self).__init__()
        self.output_dim = out_features

    def forward(self, x):
        return x.view(-1, self.output_dim)

class Reshape(nn.Module):
    def __init__(self, out_shape):
        super(Reshape, self).__init__()
        self.out_shape = out_shape

    def forward(self, x):
        return x.reshape(-1, *self.out_shape)
        # return x.reshape(-1, *correct_out_shape)



class SelfAttention(nn.Module):
    def __init__(self, input_dim):
        super(SelfAttention, self).__init__()
        self.query = nn.Linear(input_dim, input_dim)
        self.key = nn.Linear(input_dim, input_dim)
        self.value = nn.Linear(input_dim, input_dim)
        self.layer_norm = nn.LayerNorm(input_dim)

    def forward(self, x):
        q = self.query(x)
        k = self.key(x)
        v = self.value(x)

        attn_weights = F.softmax(torch.matmul(q, k.transpose(-2, -1)) / np.sqrt(x.size(-1)), dim=-1)
        out = torch.matmul(attn_weights, v)
        out = self.layer_norm(out)
        return out





class Classification(nn.Module):
    def __init__(self, num_classes, input_size, n_channels=32, n_inception_blocks=6):
        super(Classification, self).__init__()

        layers = [InceptionBlock(1, n_channels, [5, 11, 23], 32, True, nn.ReLU())]

        for _ in range(n_inception_blocks - 1):
            layers.append(InceptionBlock(n_channels * 4, n_channels, [5, 11, 23], 32, True, nn.ReLU()))

        self.model = nn.Sequential(
            Reshape(out_shape=(1, input_size)),
            *layers,
            nn.AdaptiveAvgPool1d(output_size=1),
            Flatten(out_features=n_channels * 4),
            SelfAttention(input_dim=n_channels * 4),
            nn.Linear(in_features=n_channels * 4, out_features=num_classes)
        )

    def forward(self, x):
        x = self.model(x)
        return x

