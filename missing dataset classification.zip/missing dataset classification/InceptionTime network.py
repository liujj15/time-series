import torch
import torch.nn as nn
import torch.nn.functional as F


class Inception(nn.Module):
    def __init__(self, input_channels, output_channels, bottleneck_channels):
        super(Inception, self).__init__()
        self.bottleneck = nn.Conv1d(input_channels, bottleneck_channels, kernel_size=1)

        self.conv1 = nn.Conv1d(bottleneck_channels, output_channels, kernel_size=39, padding=19)
        self.conv2 = nn.Conv1d(bottleneck_channels, output_channels, kernel_size=19, padding=9)
        self.conv3 = nn.Conv1d(bottleneck_channels, output_channels, kernel_size=9, padding=4)

    def forward(self, x):
        x = self.bottleneck(x)
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)

        return torch.cat((x1, x2, x3), 1)


class InceptionTime(nn.Module):
    def __init__(self, input_channels, output_channels, class_num, depth):
        super(InceptionTime, self).__init__()
        self.depth = depth
        self.inception = nn.ModuleList(
            [Inception(input_channels, output_channels, output_channels // 4) for _ in range(depth)])
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(output_channels * 3, class_num)

    def forward(self, x):
        for i in range(self.depth):
            x = self.inception[i](x)
            x = F.relu(x)
        x = self.global_pool(x)
        x = torch.flatten(x, 1)
        return self.fc(x)


config = {
    "input_channels": 1,  # Number of input channels, you need to set this based on your input data
    "output_channels": 32,  # Number of output channels in each Inception block
    "class_num": 10,  # Number of classes in your classification problem
    "depth": 6,  # Depth of the InceptionTime network (number of Inception blocks)
}

model = InceptionTime(**config)