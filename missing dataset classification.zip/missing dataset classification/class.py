import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset


class InceptionModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(InceptionModule, self).__init__()
        self.conv1x1 = nn.Conv1d(in_channels, out_channels, kernel_size=1)
        self.conv3x3 = nn.Conv1d(in_channels, out_channels, kernel_size=3, padding=1)
        self.conv5x5 = nn.Conv1d(in_channels, out_channels, kernel_size=5, padding=2)
        self.relu = nn.ReLU()

    def forward(self, x):
        out1 = self.conv1x1(x)
        out1 = self.relu(out1)
        out3 = self.conv3x3(x)
        out3 = self.relu(out3)
        out5 = self.conv5x5(x)
        out5 = self.relu(out5)
        out = torch.cat([out1, out3, out5], dim=1)
        return out

# 定义自注意力机制模块
class SelfAttention(nn.Module):
    def __init__(self, in_channels):
        super(SelfAttention, self).__init__()
        self.conv1x1 = nn.Conv1d(in_channels, in_channels, kernel_size=1)
        self.softmax = nn.Softmax(dim=2)

    def forward(self, x):
        out = self.conv1x1(x)
        out = self.softmax(out)
        out = torch.matmul(x.transpose(1, 2), out)
        out = out.transpose(1, 2)
        return out


class ClassificationModel(nn.Module):
    def __init__(self, input_size, num_classes):
        super(ClassificationModel, self).__init__()
        self.inception1 = InceptionModule(input_size, 32)
        self.inception2 = InceptionModule(96, 32)
        self.attention = SelfAttention(96)
        self.fc = nn.Linear(96, num_classes)

    def forward(self, x):
        out = self.inception1(x)
        out = self.inception2(out)
        out = self.attention(out)
        out = out.mean(dim=2)
        out = self.fc(out)
        return out



import torch
import numpy as np
import pandas as pd
from torch import nn
from torch.nn import functional as F

class SelfAttention(nn.Module):
    def __init__(self, dim):
        super(SelfAttention, self).__init__()
        self.dim = dim
        self.query = nn.Linear(dim, dim)
        self.key = nn.Linear(dim, dim)
        self.value = nn.Linear(dim, dim)
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        # Compute the query, key, and value vectors
        q = self.query(x)
        k = self.key(x)
        v = self.value(x)

        # Compute the attention weights
        attn = torch.einsum('ijk,ilk->ijl', q, k)
        attn = attn / np.sqrt(self.dim)
        attn = F.softmax(attn, dim=-1)

        # Compute the weighted sum of the values
        out = torch.einsum('ijl,ilk->ijk', attn, v)

        # Apply the gamma parameter
        out = self.gamma * out

        # Add the input to the output
        out = out + x

        return out

class InceptionTimeNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_layers, dropout=0.2):
        super(InceptionTimeNetwork, self).__init__()

        # Inception modules
        self.inception_modules = nn.ModuleList()
        for i in range(num_layers):
            inception_module = nn.Sequential(
                nn.Conv1d(input_dim, hidden_dim, kernel_size=1),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Conv1d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Conv1d(hidden_dim, hidden_dim, kernel_size=5, padding=2),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.MaxPool1d(kernel_size=3, stride=1, padding=1)
            )
            self.inception_modules.append(inception_module)

        # Fully connected layer
        self.fc = nn.Linear(hidden_dim * num_layers, output_dim)

    def forward(self, x):
        # Pass the input through the inception modules
        for inception_module in self.inception_modules:
            x = inception_module(x)

        # Flatten the output
        x = x.view(x.size(0), -1)

        # Pass the output through the fully connected layer
        x = self.fc(x)

        return x

class SelfAttentionInceptionTimeNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_layers, dropout=0.2):
        super(SelfAttentionInceptionTimeNetwork, self).__init__()

        # Self-attention layer
        self.self_attention = SelfAttention(input_dim)

        # Inception time network
        self.inception_time_network = InceptionTimeNetwork(input_dim, hidden_dim, output_dim, num_layers, dropout)

    def forward(self, x):
        # Pass the input through the self-attention layer
        x = self.self_attention(x)

        # Pass the output through the inception time network
        x = self.inception_time_network(x)

        return x

# Load the UCR time series data
data = pd.read_csv('')

# Preprocess the data
data = data.dropna()
data = data.values
data = data.astype(np.float32)

# Split the data into training and testing sets
train_data = data[:int(0.8 * len(data))]
test_data = data[int(0.8 * len(data)):]

# Convert the data to PyTorch tensors
train_data = torch.from_numpy(train_data)
test_data = torch.from_numpy(test_data)

# Create the model
model = SelfAttentionInceptionTimeNetwork(input_dim=1, hidden_dim=64, output_dim=6, num_layers=2)

# Define the loss function and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

# Train the model
for epoch in range(100):
    # Forward pass
    outputs = model(train_data)

    # Compute the loss
    loss = criterion(outputs, train_data)

    # Backward pass
    optimizer.zero_grad()
    loss.backward()

    # Update the weights
    optimizer.step()

# Evaluate the model on the test data
with torch.no_grad():
    outputs = model(test_data)

    # Compute the accuracy
    _, predicted = torch.max(outputs, dim=1)
    accuracy = (predicted == test_data).sum().item() / len(test_data)

    # Print the accuracy
    print(f'Test accuracy: {accuracy}')