import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset





class BiLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(BiLSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, bidirectional=True)
        self.fc = nn.Linear(hidden_size * 2, output_size)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_size)
        c0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_size)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out[:, -1, :])
        return out


class ELM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(ELM, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out = self.fc1(x)
        out = torch.relu(out)
        out = self.fc2(out)
        return out


class ImputationModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(ImputationModel, self).__init__()
        self.bilstm = BiLSTM(input_size, hidden_size, num_layers, output_size)
        self.elm = ELM(output_size, hidden_size, input_size)

    def forward(self, x):
        lstm_out = self.bilstm(x)
        imputed_data = self.elm(lstm_out)
        return imputed_data


import torch
import numpy as np
import pandas as pd
from torch import nn
from torch.nn import functional as F

class BiLSTM_ELM(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_layers, dropout=0.2):
        super(BiLSTM_ELM, self).__init__()

        # BiLSTM layer
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers=num_layers, bidirectional=True, dropout=dropout)

        # Fully connected layer
        self.fc = nn.Linear(hidden_dim * 2, output_dim)

        # ELM layer
        self.elm = nn.Linear(output_dim, output_dim)

    def forward(self, x):
        # BiLSTM layer
        lstm_out, _ = self.lstm(x)

        # Fully connected layer
        fc_out = self.fc(lstm_out)

        # ELM layer
        elm_out = self.elm(fc_out)

        return elm_out

# Load the UCR time series data
data = pd.read_csv('')

# Preprocess the data
data = data.dropna()
data = data.values
data = data.astype(np.float32)

# Split the data into training and testing sets
train_data = data[:int(0.8 * len(data))]
test_data = data[int(0.8 * len(data)):]

# Create the missing data mask
missing_data_mask = np.random.choice([0, 1], size=len(train_data), p=[0.8, 0.2])

# Apply the missing data mask to the training data
train_data[missing_data_mask == 1] = np.nan

# Convert the data to PyTorch tensors
train_data = torch.from_numpy(train_data)
test_data = torch.from_numpy(test_data)

# Create the model
model = BiLSTM_ELM(input_dim=1, hidden_dim=64, output_dim=1, num_layers=2)

# Define the loss function and optimizer
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

# Train the model
for epoch in range(100):
    # Forward pass
    outputs = model(train_data)

    # Compute the loss
    loss = criterion(outputs, train_data)

    # Backward pass
    optimizer.zero_grad()
    loss.backward()

    # Update the weights
    optimizer.step()

# Evaluate the model on the test data
with torch.no_grad():
    outputs = model(test_data)

    # Compute the loss
    loss = criterion(outputs, test_data)

    # Print the loss
    print(f'Test loss: {loss}')


