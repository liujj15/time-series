import os
os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import numpy as np
import argparse
import torch
from torch import nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torch import optim
from tqdm import tqdm
from torch.utils.data import DataLoader

from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import math
from scipy.stats import gaussian_kde

class ELM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(ELM, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.input_weights = nn.Parameter(torch.randn(input_size, hidden_size))
        self.output_weights = nn.Parameter(torch.randn(hidden_size, output_size))

    def forward(self, x):
        h = torch.sigmoid(x @ self.input_weights)
        y = h @ self.output_weights
        return y



class Impute(nn.Module):
    def __init__(self, config):
        super(Impute, self).__init__()
        self.batch_size = config.batch_size
        self.hidden_size = config.hidden_size
        self.num_steps = config.num_steps
        self.input_dimension_size = config.input_dimension_size
        self.cell_type = config.cell_type
        self.lamda = config.lamda
        self.class_num = config.class_num
        self.layer_num = config.layer_num
        self.elm_hidden_size = config.elm_hidden_size

        self.lstm = nn.LSTM(input_size=config.input_dimension_size,
                            hidden_size=config.hidden_size,
                            num_layers=1,  # Change this to 1
                            batch_first=True,
                            bidirectional=True)
        self.linear = nn.Linear(2 * config.hidden_size, config.input_dimension_size)

        self.imp_projection = nn.Linear(self.hidden_size * 2, self.input_dimension_size)

        self.elm = ELM(self.input_dimension_size, self.elm_hidden_size, self.class_num)

    def forward(self, x, masks):
        batch_size = x.shape[0]
        imputation_sequence = []
        completed_sequence = []

        hidden_state, cell_state = self.init_hidden(batch_size), self.init_cell(batch_size)
        seq_len = x.size(1)
        outputs, (hidden_state, cell_state) = self.lstm(x, (hidden_state, cell_state))
        outputs = outputs[:, :-1, :]  # remove last time step

        for time_step in range(seq_len - 1):
            imputed = self.imp_projection(outputs[:, time_step, :]).unsqueeze(1)
            imputation_sequence.append(imputed)
            completed_sequence.append(masks[:, time_step:time_step + 1, None] * x[:, time_step:time_step + 1, :] +
                                      (1 - masks[:, time_step:time_step + 1, None]) * imputation_sequence[time_step])

        output_elm = self.elm(completed_sequence[-1])
        return hidden_state, completed_sequence, imputation_sequence, output_elm

    def init_hidden(self, batch_size):
        return torch.zeros(self.layer_num * 2, batch_size, self.hidden_size)

    def init_cell(self, batch_size):
        return torch.zeros(self.layer_num * 2, batch_size, self.hidden_size)









class Discriminator(nn.Module):
    def __init__(self, config):
        super(Discriminator, self).__init__()
        self.name = "Discriminator"

        self.gru1 = nn.GRU(input_size=config.input_dimension_size, hidden_size=(config.num_steps-1)*config.input_dimension_size, num_layers=1, batch_first=True)
        self.gru2 = nn.GRU(input_size=(config.num_steps-1)*config.input_dimension_size, hidden_size=int(config.num_steps)//2*config.input_dimension_size, num_layers=1, batch_first=True)

        self.fc = nn.Linear(int(config.num_steps)//2*config.input_dimension_size, config.num_steps-1)

    def forward(self, x):
        x, _ = self.gru1(x)
        x = torch.tanh(x[:, -1, :])
        x = x.unsqueeze(1)
        x, _ = self.gru2(x)
        x = torch.tanh(x[:, -1, :])
        return self.fc(x)







