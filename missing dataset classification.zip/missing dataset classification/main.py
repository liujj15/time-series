import os
os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'
import numpy as np
import argparse
import torch
from torch import nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torch import optim
from tqdm import tqdm
from torch.utils.data import DataLoader

from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import math
from scipy.stats import gaussian_kde
from impute import Impute,Discriminator

from Classification import Classification


Missing_value = 100.0
#torch.autograd.set_detect_anomaly(True)

# Set device cuda for GPU if it's available otherwise run on the CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def loss_D(scores, masks):
    n = scores.shape[0]
    loss = torch.sum((1-masks[:, 1:]) * torch.log((1-torch.sigmoid(scores)).clamp(min=1e-4)))
    loss += torch.sum(masks[:, 1:] * torch.log(torch.sigmoid(scores)))
    loss /= -n

    return loss

    return torch.sum((1-masks[:, 1:]) * torch.log((1-torch.sigmoid(scores)).clamp(min=1e-4)))/n


def focal_loss(scores, masks, alpha=0.25, gamma=2.0):
    n = scores.shape[0]
    prob = torch.sigmoid(scores)
    pt = prob * masks[:, 1:] + (1 - prob) * (1 - masks[:, 1:])
    weight = alpha * (1 - pt).pow(gamma)
    loss = -weight * torch.log(pt.clamp(min=1e-4))
    return loss.sum() / n

def loss_adv(scores, masks):

    return focal_loss(scores, masks)




def loss_cls(logits, labels, C, alpha=0.5, l1_ratio=0.5):
    # 计算交叉熵损失
    ce_loss = nn.functional.cross_entropy(logits, labels)


    l1_loss = 0
    l2_loss = 0


    for param in C.parameters():
        l1_loss += torch.sum(torch.abs(param))
        l2_loss += torch.sum(param ** 2)

    # 计算Elastic Net正则化损失
    en_loss = l1_ratio * l1_loss + (1 - l1_ratio) * l2_loss


    total_loss = ce_loss + alpha * en_loss

    return total_loss


def loss_imp(completed_seq, imputation_seq, masks):
    completed_seq_tensor = torch.cat(completed_seq, dim=1)
    imputation_seq_tensor = torch.cat(imputation_seq, dim=1)
    n = completed_seq_tensor.shape[0]

    return torch.sum(
            torch.square(
             (completed_seq_tensor-imputation_seq_tensor)*masks[:, 1:, None]
            )
           )/n






def compute_gradient_penalty(D, real_samples, fake_samples):
    alpha = torch.rand(real_samples.size(0), 1, 1).to(device)
    interpolates = (alpha * real_samples + (1 - alpha) * fake_samples).requires_grad_(True)
    d_interpolates = D(interpolates)
    gradients = torch.autograd.grad(
        outputs=d_interpolates,
        inputs=interpolates,
        grad_outputs=torch.ones(d_interpolates.size()).to(device),
        create_graph=True,
        retain_graph=True,
        only_inputs=True,
    )[0]
    gradients = gradients.view(gradients.size(0), -1)
    gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
    return gradient_penalty



def main(config):
    print (f'Training data: {config.train_data_filename}')
    train_dataset = ITSCDataset(config.train_data_filename, config.missing_frac)
    test_dataset = ITSCDataset(config.test_data_filename)

    train_loader = DataLoader(train_dataset, batch_size=config.batch_size,
                        shuffle=True, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=config.batch_size,
                        shuffle=True, num_workers=0)

    config.class_num = train_dataset.num_classes
    config.num_steps = train_dataset[0][0].shape[0]
    config.input_dimension_size = train_dataset[0][0].shape[1]
    print(f'Num steps = {config.num_steps}')
    print(f'Input dimension size = {config.input_dimension_size}')
    print(f'Num classes = {config.class_num}')

    # ---------------train------------------

    I = Impute(config).to(device)
    C = Classification(config.class_num, config.hidden_size, n_channels=64, n_inception_blocks=8)
    D = Discriminator(config).to(device)
    I_optim = optim.Adam(I.parameters(), lr=config.learning_rate)
    C_optim = optim.Adam(C.parameters(), lr=config.learning_rate*2)
    D_optim = optim.Adam(D.parameters(), lr=config.learning_rate)

    for epoch in range(config.epoch):
        epoch_loss_D = 0
        epoch_loss_total = 0
        epoch_loss_cls = 0
        epoch_loss_imp = 0
        epoch_loss_adv = 0
        samples = 0
        correct = 0
        n_batches = 0
        all_preds = []
        all_targets = []
        mse_sum = 0



        print(f'Epoch {epoch+1}/{config.epoch}: ')
        for batch_idx, (data,masks,targets) in enumerate(tqdm(train_loader)):
            # Get data to cuda if possible
            original_data = data.clone()
            data = data.to(device=device)
            masks = masks.to(device=device)
            #targets = targets.to(device=device)
            targets = targets.to(device).view(-1, 1).repeat(1, 2).view(-1)
            #targets = targets.to(config.device).view(-1)
            targets = targets.type(torch.LongTensor)
            samples += data.shape[0]

            #hidden_state, completed_seq, imputation_seq = G(data, masks)

            hidden_state, completed_seq, imputation_seq, output_elm = I(data, masks)

            logits = C(hidden_state)
            #logits = C(hidden_state.unsqueeze(1))

            completed_seq_tensor = torch.cat(completed_seq, dim=1)
            scores = D(completed_seq_tensor)



            # Calculate MSE
            original_data_np = data.cpu().numpy()
            completed_seq_np = completed_seq_tensor.detach().cpu().numpy()

            min_len = min(original_data_np.shape[1], completed_seq_np.shape[1])
            mse_per_sample = np.mean((original_data_np[:, :min_len] - completed_seq_np[:, :min_len]) ** 2, axis=-1)
            mse = np.mean(mse_per_sample)
            mse_sum += mse

            # 计算梯度惩罚
            gradient_penalty = compute_gradient_penalty(
                D, data[:, 1:, :], torch.cat(imputation_seq, 1)
            )


            with torch.no_grad():
                probs = torch.softmax(logits, dim=1)
                preds = torch.argmax(probs, dim=1)
                correct += torch.sum((preds == targets).float()).detach().item()
                all_preds.append(preds)
                all_targets.append(targets)

            #loss calculations 计算损失
            #l_D = loss_D(scores,masks)
            l_D = loss_D(scores, masks) + config.lamda_GP * gradient_penalty

            #backward
            D_optim.zero_grad()
            l_D.backward(retain_graph=True)

            epoch_loss_D += l_D.detach().cpu().item()

            # Combined loss
            l_imp = loss_imp(completed_seq,imputation_seq,masks) #缺失值填充损失值
            #l_cls = loss_cls(logits,targets)  #分类损失值
            l_cls = loss_cls(logits, targets, C, alpha=0.5, l1_ratio=0.5)
            l_adv = loss_adv(scores,masks) #对抗损失值
            l_total = l_cls + l_imp + config.lamda_D * l_adv #综合损失值
            epoch_loss_cls += l_cls.detach().cpu().item()
            epoch_loss_adv += l_adv.detach().cpu().item()
            epoch_loss_imp += l_imp.detach().cpu().item()
            epoch_loss_total += l_total.detach().cpu().item()

            C_optim.zero_grad()
            I_optim.zero_grad()

            for p in D.parameters(): p.requires_grad_(False)
            l_total.backward()
            for p in D.parameters(): p.requires_grad_(True)

            C_optim.step()
            I_optim.step()
            D_optim.step()

            n_batches += 1
        #print(f'D Loss per batch: {epoch_loss_D/n_batches}')
        #print(f'AJ-RNN Loss per batch: {epoch_loss_total/n_batches}')
        print(f'Classification loss per batch: {epoch_loss_cls/n_batches}')
        print(f'Imputation loss per batch: {epoch_loss_imp/n_batches}')
        print(f'Adversarial loss per batch: {epoch_loss_adv/n_batches}')
        #print(f'Adversarial loss per batch: {mse_sum / mse_count}')
        print(f'RMSE: {math.sqrt(mse_sum / (n_batches * config.epoch))}')
        print(f'Train Accuracy: {correct/samples*100:.2f}%')
        # After calculating MSE
        true_data_var = np.var(original_data_np[:, :min_len], axis=0)
        R2 = 1 - (mse / true_data_var.mean())
        print(f'R^2: {R2}')



    # ---------------test------------------

    mse_sum = 0
    correct = 0
    n_batches = 0
    samples = 0


    test_loss_imp = 0
    test_loss_cls = 0
    test_loss_adv = 0
    true_values = []
    predicted_values = []
    # if len(test_loader) == 0:
    #     print("Test data not loaded properly. Please check the data file path and content.")
    #     return

    for batch_idx, (data, masks, targets) in enumerate(tqdm(test_loader)):
        data = data.to(device=device)
        masks = masks.to(device=device)
        targets = targets.to(device).view(-1, 1).repeat(1, 2).view(-1)
        targets = targets.type(torch.LongTensor)

        samples += data.shape[0]

        with torch.no_grad():
            hidden_state, completed_seq, imputation_seq, output_elm = I(data, masks)
            logits = C(hidden_state)
            completed_seq_tensor = torch.cat(completed_seq, dim=1)

            # Calculate loss values
            l_imp_test = loss_imp(completed_seq, imputation_seq, masks)
            l_cls_test = loss_cls(logits, targets, C, alpha=0.5, l1_ratio=0.5)
            scores_test = D(completed_seq_tensor)
            l_adv_test = loss_adv(scores_test, masks)

            # Accumulate the loss values
            test_loss_imp += l_imp_test.detach().cpu().item()
            test_loss_cls += l_cls_test.detach().cpu().item()
            test_loss_adv += l_adv_test.detach().cpu().item()

            original_data_np = data.cpu().numpy()
            completed_seq_np = completed_seq_tensor.detach().cpu().numpy()
            min_len = min(original_data_np.shape[1], completed_seq_np.shape[1])
            mse_per_sample = np.mean((original_data_np[:, :min_len] - completed_seq_np[:, :min_len]) ** 2, axis=-1)
            mse = np.mean(mse_per_sample)
            mse_sum += mse

            probs = torch.softmax(logits, dim=1)
            preds = torch.argmax(probs, dim=1)
            correct += torch.sum((preds == targets).float()).detach().item()
            # 将预测值和真实值存储起来
            predicted_values.extend(completed_seq_tensor.cpu().numpy().tolist())
            true_values.extend(data.cpu().numpy().tolist())

        n_batches += 1

    print(f'Test Imputation Loss: {test_loss_imp / n_batches}')
    print(f'Test Classification Loss: {test_loss_cls / n_batches}')
    print(f'Test Adversarial Loss: {test_loss_adv / n_batches}')
    print(f'Test Accuracy: {correct / samples * 100:.2f}%')
    # if samples > 0:
    #     print(f'Test Accuracy: {correct / samples * 100:.2f}%')
    # else:
    #     print("There are no samples to calculate the test accuracy.")
    print(f'Test RMSE: {math.sqrt(mse_sum / n_batches)}')
    # After calculating MSE
    true_data_var = np.var(original_data_np[:, :min_len], axis=0)
    R2 = 1 - (mse / true_data_var.mean())
    print(f'Test R^2: {R2}')




class Config:
    def __init__(self, params):
        self.batch_size = params["batch_size"]
        self.epoch = params["epoch"]
        self.lamda_D = params["lamda_D"]
        self.missing_frac = params["missing_frac"]
        self.I_epoch = 50
        self.train_data_filename = params["train_data_filename"]
        self.test_data_filename = params["test_data_filename"]
        self.layer_num = params["layer_num"]
        self.hidden_size = params["hidden_size"]
        self.learning_rate = params["learning_rate"]
        self.cell_type = "LSTM"
        self.lamda = 1
        self.D_epoch = 1
        self.GPU = "0"
        self.elm_hidden_size = 128
        self.class_num = 4
        self.hidden_size = 100
        self.num_channels = 32
        self.num_inception_blocks = 6





if __name__ == "__main__":
    params = {
        "batch_size": 50,
        "epoch": 5,
        "lamda_D": 1,
        "G_epoch": 5,
        "input_dimension_size":2,
        "train_data_filename": "dataset/Adiac/Adiac_TRAIN.tsv",
        "test_data_filename": "dataset/Adiac/Adiac_TEST.tsv",
        "hidden_size": 50,
        "layer_num": 1,
        "missing_frac": 0.5,#缺失率
        "learning_rate": 0.05,

    }
    config = Config(params)
    config.elm_hidden_size = 128
    config.lamda_GP = 10
    main(config)



