import numpy as np
import pandas as pd


full_train_data = pd.read_csv('./CBF/CBF_TRAIN', delimiter="\t",header = None)
full_test_data = pd.read_csv('./CBF/CBF_TEST', delimiter="\t",header = None)





